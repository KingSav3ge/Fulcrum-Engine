# Kira v0.5 — the expanded setting is canon

The creator has adopted the expanded Larius lore as the working canon. Start with world/larius/LARIUS_LOREBOOK.md and world/larius/KIERAN_PELLEAS.md. The two manuscripts contain approximately 15,400 words. world/canon.json records authority and editorial decisions.

The eight religious traditions, expanded cultures, institutions, supporting cast, Sivren, Keld, Vesh and Kieran’s Long Renewal are established setting material. The original Word documents are a superseded creative archive with no authority to overrule the current setting. Their bytes and transcription remain preserved for creative history.

The continental war spans 80–400 A.A., with Kieran’s 228 years describing active wartime service. Independence belongs to 500 A.A.; Estru’s later invasion belongs to 600 A.A. Karkaria, Evalia, Ikarion and Daniel Convor are the current names. The Long Renewal explains Kieran’s exceptional age. Exact constitutions, some caste positions, distances and numerical magic rules remain further development.

Story possibilities retain open outcomes, religious claims remain attributed beliefs, and existing campaigns retain their committed history. This package selects no player or starting snapshot and changes no executable mechanics.

## Integrating the reference content

The world directory is self-contained. Run python -B verify_kira.py inside it. Its public guide projection is used by the canonical IRGS Content Library.

Kira_IRGS_v0_5_full.patch integrates the complete world into the captured pre-Kira unified D1 working source. Kira_v0_4_to_v0_5.patch upgrades a source tree matching the supplied v0.4 package. Use the matching patch; do not apply both. Keep this extracted bundle outside the checkout, run git apply --check on the selected patch, then reconcile and apply while preserving local edits. Do not copy new world files into the checkout first if applying a patch that adds them.

Both patches passed forward and reverse checks against their captured baselines. Patched world packages and an extracted ZIP passed the canon verifier. A diverged checkout may need a merge. The Windows installation has not been modified. Follow the repository’s release-pin and development-manifest workflow after reconciling local source. VALIDATION.json records the checks executed for this revision.
