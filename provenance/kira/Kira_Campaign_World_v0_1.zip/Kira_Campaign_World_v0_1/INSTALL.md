# Kira campaign world v0.1

This bundle contains a reusable IRGS world reference, with Larius, TalmahKah, Aldain, Azaloth, Falkion and Bendara on separate continental shelves. Falkion has no forced continent designation. The written reference year is 1342 A.A.

Read `world/WORLD_GUIDE.md`, `world/MAP_GAZETTEER.md` and `world/CONTINUITY_REVIEW.md`. The nine original Word documents are in `world/sources/`. The six map images remain in the chat; this bundle contains transcriptions and descriptive references rather than original image files.

## Use the world content separately

The `world` folder is a self-contained reference package. Run `python -B verify_kira.py` inside it. To retain it as source content in IRGS, copy that folder to `IRGS_3_3/catalog/campaigns/kira/`. Copying content alone does not add the website controls.

## Integrate into the canonical IRGS development site

The patch contains both the world source package and the Content Library integration, with tests and source-integrity pins. It was built against the current unified D1 cloud working source, preserving the pre-existing Adventure UI work. Your Windows installation has not been modified.

Keep this extracted bundle outside the target checkout. From a matching IRGS development repository root, inspect the patch, run `git apply --check <path-to-Kira_IRGS_integration.patch>`, then apply it with `git apply <path-to-Kira_IRGS_integration.patch>`. Do not copy the world folder into the target first if applying the patch. If your checkout has diverged, reconcile the patch with that local source and preserve existing edits.

Run `python -B IRGS_3_3/catalog/campaigns/kira/verify_kira.py` and `python -B tools/verify_development.py`. If local source differs, refresh the intended release pins and development manifest through the repository's documented workflow after reconciling it.

Open Content Library → The World of Kira → Read world guide. Kira is a campaign world in development, not a created player save. Launchable starting snapshots, exact map dates and scales, and numerical magic/technology choices remain unselected.
